
public class DriveTask_1 {

	public static void main(String[] args) {
		Pet animal[]=new Pet[6];
		animal[0]=new Dog("Tommy","Black");
		animal[1]=new Dog("Lali","Red");
		
		animal[2]=new Cat("Kery","white");
		animal[3]=new Cat("Pery","Brown");
		
		animal[4]=new Rabit("Snow","White");
		animal[5]=new Rabit("Snowy","White");
		
		int upper=5,lower=0;
		int n=(int)(Math.random()*(upper-lower+1)+1);
		System.out.println("Random number: "+n);
		
		for(int i=0;i<animal.length;i++) {
			if(i==n) {
				System.out.println(animal[i].toString());
			}
				
		}
		
		
		

	}

}
