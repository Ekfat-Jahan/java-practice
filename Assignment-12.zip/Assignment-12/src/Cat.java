
public class Cat extends Pet {
	//constructor
		public Cat(String name, String color) {
			
			super(name,color);
		}

		public String sound() {
			return "meow meow";
		}
		@Override
		public String toString() {
			return "Cat [name=" + super.getName() + ", color=" + super.getColor() +", sound="+sound()+ "]";
		}


}
