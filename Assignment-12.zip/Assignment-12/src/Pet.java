//task-1
public class Pet {
	//data field
private String name;
private String color;
//constructor
public Pet(String name, String color) {
	
	this.setName(name);
	this.setColor(color);
}
//getter settter
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}

public String sound() {
	return "Null";
}

@Override
public String toString() {
	return "Pet [name=" + name + ", color=" + color + "]";
}


}
