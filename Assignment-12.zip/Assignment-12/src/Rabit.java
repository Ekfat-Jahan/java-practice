public class Rabit extends Pet {
	//constructor
		public Rabit(String name, String color) {
			
			super(name,color);
		}

		public String sound() {
			return "squeak squeak";
		}
		@Override
		public String toString() {
			return "rabit [name=" + super.getName() + ", color=" + super.getColor() +", sound="+sound()+ "]";
		}


}



