
public class Dog extends Pet{
	
	//constructor
	public Dog(String name, String color) {
		
		super(name,color);
	}

	public String sound() {
		return "woof woof";
	}
	@Override
	public String toString() {
		return "Dog [name=" + super.getName() + ", color=" + super.getColor() +", sound="+sound()+ "]";
	}

}
