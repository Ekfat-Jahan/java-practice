//task-3
public class FullTimeEmployee extends Employee3 {
	//data field
	private double basic;
	private double allowance;
	
	//default constructor
	public FullTimeEmployee() {}
	//parameter constructor
	public FullTimeEmployee(String name, int age, String address,String designation, String department,double basic, double allowance) {
		super(name,age,address,designation,department);
		this.setBasic(basic);
		this.setAllowance(allowance);
	}
	
	//getter setter method
	public double getBasic() {
		return basic;
	}
	public void setBasic(double basic) {
		this.basic = basic;
	}
	public double getAllowance() {
		return allowance;
	}
	public void setAllowance(double allowance) {
		this.allowance = allowance;
	}
	
	//method
	public double salary() {
		return basic+((allowance*basic)/100);
	}
	@Override
	public String toString() {
		return "FullTimeEmployee [basic=" + basic + ", allowance=" + allowance + "]";
	}
	
	
	
	

}
