//task-7
public class Circle7 extends GeometricObject{
	//data field
		private double radius;
		//default constructor
		public Circle7() {}
		//parameter constructor
		
		public Circle7(double radius) {
			this.radius = radius;
		}
		
		public Circle7(double radius,String color, boolean filled) {
			super(color,filled);
			this.radius = radius;
		}
		public double getRadius() {
			return radius;
		}
		public void setRadius(double radius) {
			this.radius = radius;
		}
		
	//	get perimeter
		public double getPerimeter() {
			return 2*Math.PI*radius;
		}
		//get diameter
		public double getDiameter() {
			return 2*radius;
		}
		//get area
		public double getArea() {
			return Math.PI*Math.pow(radius, 2);
		}
		@Override
		public String toString() {
			return "Circle7 [radius=" + radius + "]";
		}
	
		//print circle
		public void printCircle() {
			System.out.println( "Circle7 [color=" + super.getColor() +", filled="+super.getFilled()+", radius="+radius+", perimeter="+getPerimeter()+", diameter="+getDiameter()+", area="+getArea()+ "]");
		}
}
