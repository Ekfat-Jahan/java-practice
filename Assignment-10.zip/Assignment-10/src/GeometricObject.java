//task-7
public class GeometricObject {
//data field
	private String color;
	private boolean filled;
	
	//default constructor
	public GeometricObject() {}
//parameter constructor
	public GeometricObject(String color, boolean filled) {
		this.color = color;
		this.filled = filled;
	}
	//getter setter method
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public boolean getFilled() {
		return filled;
	}
	public void setFilled(boolean filled) {
		this.filled = filled;
	}
	@Override
	public String toString() {
		return "GeometricObject [color=" + color + ", filled=" + filled + "]";
	}
	
	
	
}
