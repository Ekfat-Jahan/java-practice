//task-1
public class DriveTask_1 {

	public static void main(String[] args) {
		Rectangle objR=new Rectangle("Rectangle",5,6);
		Square objS=new Square("Squsre",5);
		System.out.println(objR.toString());
		System.out.println(objS.toString());

	}

}
