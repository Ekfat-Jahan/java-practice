
public class DriveTask_3 {
	public static void main(String[] args) {
		Employee3 p1=new PartTimeEmployee3("Tahmid Shah",25,"25/A Dhanmondi","Junior Officer","Marketing",3,2000);
		Employee3 p2=new FullTimeEmployee("Nafi Abdullah",39,"134/B Mirpur","DGM","Customer service",90000,25);
		
		System.out.println("Part time employee salary:"+p1.salary());
		System.out.println("Full time employee salary:"+p2.salary());
	}

}
