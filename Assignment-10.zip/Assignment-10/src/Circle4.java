//task4
public class Circle4 extends Shape4{
	//data field
	private int circleCounter=0;
	private double radius;
	
	//default constructor
	public Circle4() {}
	
//parameter constructor
	public Circle4(double dim1, double dim2, double radius) {
		super(dim1, dim2);
		this.radius=radius;
	}
//getter setter method
	public int getCircleCounter() {
		return circleCounter;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	//method
	public double getArea() {
		return Math.PI*Math.pow(radius, 2);
	}

	@Override
	public String toString() {
		return "Circle4 [circleCounter=" + circleCounter + ", radius=" + radius +", area= "+getArea()+"]";
	}

}
