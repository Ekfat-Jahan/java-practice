//task-6
public class Cylinder extends Circle6{
	//data field
		private double height=1;
		
		
		//default constructor
		public Cylinder() {}

		//parameter constructor
		public Cylinder(double height) {
			this.height=height;
		}
		public Cylinder(double height ,double radius) {
			super(radius);
			this.height=height;
		}

		public Cylinder(double height,double radius, String color) {
			super(radius,color);
			this.height=height;
		}
//getter-setter method
		public double getHeight() {
			return height;
		}

		public void setHeight(double height) {
			this.height = height;
		}
		
	public double getVolume() {
		return Math.PI*Math.pow(super.getRadius(), 2)*height;
	}
	@Override
	public String toString() {
		return "Cylinder [radius=" +super.getRadius() + ", color=" + super.getColor() + ", volume="+getVolume()+"]";
	}
}
