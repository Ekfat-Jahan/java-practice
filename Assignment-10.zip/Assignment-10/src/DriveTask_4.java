
public class DriveTask_4 {

	public static void main(String[] args) {
		Circle4 c=new Circle4(1,2,3);
		Rectangle4 r=new Rectangle4(1,2,3,4);
		System.out.println("Area of circle:"+c.getArea());
		System.out.println(c.toString());
		System.out.println("Area of Rectangle:"+r.getArea());
		System.out.println(r.toString());

	}

}
