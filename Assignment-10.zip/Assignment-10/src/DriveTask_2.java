
public class DriveTask_2 {

	public static void main(String[] args) {
		Faculty objF=new Faculty("Karim","Male",29,"45T#6","ECE",100000.00,"KR","Professor");
System.out.println(objF.view());
System.out.println(objF.toString());
	}

}
