//task-2
public class Faculty extends Employee{
	//data field
	String initial;
	String rank;
	
	//constructor
	Faculty(String name,String gender,int age,String id,String department,double salary,String initial,String rank){
		super(name,gender,age,id,department,salary);
		this.initial=initial;
		this.rank=rank;
	}
	
	//methods
	public String view() {
		return "Name="+this.getName()+", Age="+this.getAge()+", Salary="+this.getSalary()+", Initial="+initial;
	}
	
	@Override
	public String toString() {
		return "Faculty [Name="+this.getName()+", Gender="+this.getGender()+",Age="+this.getAge()+"Id=" + this.getId() + ", Department=" + getDepartment() + ", Salary=" +this.getSalary() +", Initial=" + initial + ", rank=" + rank + "]";
	}

}
