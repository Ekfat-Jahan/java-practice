//task-5
public class Point3D extends  Point2D {
	//data field 
		private int z=0;
		//default constructor
		Point3D(){}
		//parameter constructor
	public Point3D(int x, int y,int z) {
		super(x,y);
		this.setZ(z);
	}
	//getter setter method
	public int getZ() {
		return z;
	}
	public void setZ(int z) {
		this.z = z;
	}
	@Override
	public String toString() {
		return "Point3D [x=" + super.getX() +", y="+ super.getY() +", z="+z +"]";
	}

}
