//task-3
public class Employee3 extends Person3 {
	
	//data field
	private String designation;
	private String department;
	//default constructor
	public Employee3() {}
//parameter constructor
	public Employee3(String name, int age, String address,String designation, String department) {
		super(name,age,address);
		this.setDesignation(designation);
		this.setDepartment(department);
	}
//getter setter method
	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	
	public double salary() {
		return 0;
	}
		
		}
	
	

