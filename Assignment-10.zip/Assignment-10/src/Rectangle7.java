//task-6
public class Rectangle7 extends GeometricObject{
	//data field
			private double width;
			private double height;
			//default constructor
			public Rectangle7() {}
			//parameter constructor
			
			public Rectangle7(double width,double height) {
				this.setWidth(width);
				this.setHeight(height);
			}
			
			public Rectangle7(double width,double height,String color, boolean filled) {
				super(color,filled);
				this.setWidth(width);
				this.setHeight(height);
			}
			
			//getter-setter method
			
			public double getWidth() {
				return width;
			}

			public void setWidth(double width) {
				this.width = width;
			}

			public double getHeight() {
				return height;
			}

			public void setHeight(double height) {
				this.height = height;
			}
			
			
		//	get perimeter
			public double getPerimeter() {
				return 2*(height+width);
			}
			//get diameter
			public double getDiameter() {
				return Math.sqrt((Math.pow(width, 2)+Math.pow(height,2)));
			}
			//get area
			public double getArea() {
				return width*height;
			}
			
		
			@Override
			public String toString() {
				return "Rectangle7 [width=" + width + ", height=" + height + "]";
			}

			//print circle
			public void printCircle() {
				System.out.println( "Rectangle7[color=" + super.getColor() +", filled="+super.getFilled()+",width=" + width + ", height=" + height+", perimeter="+getPerimeter()+", diameter="+getDiameter()+", area="+getArea()+ "]");
			}

			

}
