//task-3
public class Person3 {
	//data field
	private String name;
	private int age;
	private String address;
	//default constructor
	public Person3() {}
//Parameter constructor
	public Person3(String name, int age, String address) {
		
		this.name = name;
		this.age = age;
		this.address = address;
	}
//getter-setter method
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	

}
