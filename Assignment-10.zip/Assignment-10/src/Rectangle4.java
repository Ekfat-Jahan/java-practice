//task4
public class Rectangle4 extends Shape4 {
	//data field
		private int circleCounter=0;
		private double side1;
		private double side2;
		
		//default constructor
		public Rectangle4 () {}
		
	//parameter constructor
		public Rectangle4(double dim1, double dim2, double side1,double side2) {
			super(dim1, dim2);
			this.side1=side1;
			this.side2=side2;
		}
	//getter setter method
		public int getCircleCounter() {
			return circleCounter;
		}

		

		public double getSide1() {
			return side1;
		}

		public void setSide1(double side1) {
			this.side1 = side1;
		}

		public double getSide2() {
			return side2;
		}

		public void setSide2(double side2) {
			this.side2 = side2;
		}
		//method
				public double getArea() {
					return side1*side2;
				}

				

				@Override
				public String toString() {
					return "Rectangle4 [circleCounter=" + circleCounter + ", side1=" + side1 + ", side2=" + side2 + ", area="+getArea()+"]";
				}

}
