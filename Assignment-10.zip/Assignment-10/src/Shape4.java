//Task-4
public class Shape4 {
//data field 
	private double dim1;
	private double dim2;
	
	Shape4(){}
//parameter constructor
	public Shape4(double dim1, double dim2) {
		super();
		this.setDim1(dim1);
		this.setDim2(dim2);
	}
//getter setter method
	public double getDim1() {
		return dim1;
	}

	
	public void setDim1(double dim1) {
		this.dim1 = dim1;
	}

	public double getDim2() {
		return dim2;
	}

	public void setDim2(double dim2) {
		this.dim2 = dim2;
	}
	@Override
	public String toString() {
		return "Shape4 [dim1=" + dim1 + ", dim2=" + dim2 + "]";
	}
	
}
