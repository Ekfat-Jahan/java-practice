
public class DriveTask_7 {
	public static void main(String[] args) {
		
	Circle7 c1=new Circle7(2);
	System.out.println("Perimeter of circle:"+c1.getPerimeter());
	System.out.println("Diameter of circle:"+c1.getDiameter());
	System.out.println("Area of circle:"+c1.getArea());
	
	Circle7 c2=new Circle7(2,"Red",true);
	c2.printCircle();
	
	Rectangle7 r1=new Rectangle7(3,4);
	System.out.println("Perimeter of Rectangle:"+r1.getPerimeter());
	System.out.println("Diameter of Rectangle:"+r1.getDiameter());
	System.out.println("Area of Rectangle:"+r1.getArea());
	Rectangle7 r2=new Rectangle7(3,4,"Blue",false);
	r2.printCircle();
	
	
	

}
}
