
public class DriveTask_5 {

	public static void main(String[] args) {
		Point2D p1= new Point2D(1,2);
		Point3D p2= new Point3D(2,3,4);
		System.out.println(p1.toString());
		System.out.println(p2.toString());

	}

}
