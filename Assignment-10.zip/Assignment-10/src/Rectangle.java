//task-1
public class Rectangle extends Shape {
	//data field
	private double side1;
	private double side2;
	
	//constructor with parameter
	Rectangle(String name,double side1, double side2){
		super(name);
		this.side1=side1;
		this.setSide2(side2);
	}
	
	//getter setter method
	public void setSide1(double side1) {
		this.side1=side1;
	}
	
	public double getSide1() {
		return side1;
	}

	public double getSide2() {
		return side2;
	}

	public void setSide2(double side2) {
		this.side2 = side2;
	}
	//area
	public double area() {
		return side1*side2;
	}
	
	//permeter
	public double perimeter() {
		return (2*(side1+side2));
	}
	
public	String toString() {
		return "Name="+this.getName()+", Side1="+side1+", Side2="+side2+", Area="+area()+", Perimeter="+perimeter();
	}
	

}
