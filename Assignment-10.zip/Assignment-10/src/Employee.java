//task-2
public class Employee extends Person {
	//data field
	private String id;
	private String department;
	private double salary;
	
	//constructor
	Employee(String name,String gender,int age,String id,String department,double salary){
		super(name,gender,age);
		this.setId(id);
		this.setDepartment(department);
		this.setSalary(salary);
		
	}
	
	//methods

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [Name="+this.getName()+", Gender="+this.getGender()+",Age="+this.getAge()+"Id=" + id + ", Department=" + department + ", Salary=" + salary + "]";
	}
	
	
	

}
