//task-6
public class Circle6 {
	//data field
	private double radius=1;
	private String color="red";
	
	//default constructor
	public Circle6() {}

	//parameter constructor
	public Circle6(double radius) {
		this.radius=radius;
	}
	public Circle6(double radius, String color) {
		super();
		this.radius=radius;
		this.color=color;
	}
//getter-setter method
	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	//method
	public double getArea() {
		return Math.PI*Math.pow(radius,2);
	}

	@Override
	public String toString() {
		return "Circle6 [radius=" + radius + ", color=" + color + ", area="+getArea()+"]";
	}

}
