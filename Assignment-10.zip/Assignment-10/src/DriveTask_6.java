
public class DriveTask_6 {

	public static void main(String[] args) {
		Circle6 c1=new Circle6(2);
		System.out.println("Area="+c1.getArea());
		Circle6 c2=new Circle6(2,"Red");
		System.out.println(c2.toString());
		
		Cylinder cobj1=new Cylinder(3);
		System.out.println("Volume1="+cobj1.getVolume());
		
		Cylinder cobj2=new Cylinder(3,2);
		System.out.println("Volume2="+cobj2.getVolume());
		
		Cylinder cobj3=new Cylinder(4,2,"Blue");
		System.out.println(cobj3.toString());
	}

}
