//task1
public class Square extends Rectangle {
	Square(String name,double side1){
		super(name,side1,side1);
	}
	@Override
	public double area() {
		return Math.pow(getSide1(),2);
	}
	@Override
	public double perimeter() {
		return (4*getSide1());
	}
	@Override
	public String toString() {
		return "Name="+this.getName()+", Side1="+this.getSide1()+", Area="+area()+", Perimeter="+perimeter();
	}
	

}
