//task-3
public class PartTimeEmployee3 extends Employee3 {
//data field
	private double hour;
	private double rate;
	
	//default constructor
	public PartTimeEmployee3() {}
	//parameter constructor
	public PartTimeEmployee3(String name, int age, String address,String designation, String department,double hour, double rate) {
		super(name,age,address,designation,department);
		this.setHour(hour);
		this.setRate(rate);
	}
	public double getHour() {
		return hour;
	}
	public void setHour(double hour) {
		this.hour = hour;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	
	//method
	@Override
	public double salary() {
		return hour*rate;
	}
	@Override
	public String toString() {
		return "PartTimeEmployee3 [hour=" + hour + ", rate=" + rate + "]";
	}
	
}
