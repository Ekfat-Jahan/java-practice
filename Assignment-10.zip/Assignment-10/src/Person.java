//task-2
public class Person {
	//data field
	private String name;
	private String gender;
	private int age;
	//constructor
	Person(String name,String gender,int age){
		this.name=name;
		this.gender=gender;
		this.age=age;
	}
	//method
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public String toString() {
		return "Person [name=" + name + ", gender=" + gender + ", age=" + age + "]";
	}
	

}
