//task-1

public class Shape {
private String name;
//constructor with parameter
Shape(String name){
	this.setName(name);
}
//getting getter-setter method
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
